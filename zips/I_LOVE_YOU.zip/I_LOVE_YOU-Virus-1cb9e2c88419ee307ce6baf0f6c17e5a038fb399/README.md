# I_LOVE_YOU-Virus
I love you virus file (Note: free to use it will shutdown his/her computer but if it harms his/her system am not responsible)
