# Installazione
Installare vagrant da [https://www.vagrantup.com/downloads.html](https://www.vagrantup.com/downloads.html)

```
$ vagrant up
```

# Launch virus
Into the directory `test` execute `./virus`.
