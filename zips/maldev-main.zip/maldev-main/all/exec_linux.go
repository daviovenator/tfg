package all

import "github.com/D3Ext/maldev/src/exec"

func ExecuteCommand(comm string) string {
	return exec.ExecuteCommand(comm)
}
