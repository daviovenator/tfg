#!/bin/bash

# you need to have bats and sponge to run the tests

bats *.bats
