    cat inner/b.sh
