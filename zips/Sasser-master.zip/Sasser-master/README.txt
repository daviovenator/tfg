+-----------------------+
| Upload by Seth        |
| for vx.netlux.org     |
| seth@netsons.org      |
+-----------------------+

[+] This folder contains the source codes of Sasser.
    - Sasser.c 
    - Sasser_ftpd
    - Sasser_remote

+----------------------------------------+ enjoy +

